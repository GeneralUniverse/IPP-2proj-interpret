# IPP-2-interpret
This is a project for programming languages oriented course.
